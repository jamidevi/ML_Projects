from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)
model = pickle.load(open('saved_model.sav', 'rb'))

@app.route('/')
def man():
    return render_template('home.html')


@app.route('/predict', methods=['POST'])
def home():
    if request.method == 'POST':
        data1 = float(request.form['a'])
        data2 = float(request.form['b'])
        data3 = float(request.form['c'])
        data4 = float(request.form['d'])
        
        arr = np.array([[data1, data2, data3, data4]])
        prediction = model.predict(arr)
               
        return render_template('output.html', data=prediction[0])

if __name__ == '__main__':
    app.run(debug=True)
